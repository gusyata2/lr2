export default function getTitle( state ) {
	return state.documentHead.title;
}
