export default function getTags( state ) {
	return state.tags;
}
