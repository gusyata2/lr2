export default function getRequestNonce( state ) {
	return state.requests.nonce;
}
