export default function getRoutePath( state ) {
	return state.routing.path;
}
