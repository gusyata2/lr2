"Complete Tasks" icon by bezier master, with modifications, from the Noun Project (CC BY 3.0 US)
